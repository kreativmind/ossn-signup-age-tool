.aboutuser {
    text-align:left;
    font-size:13px;
}
.aboutuser td, 
.aboutuser th {
	padding:10px;
}
