# tetris
Tetris for OSSN V3.x

It's a component for Open Source Social Network v3.x (https://github.com/opensource-socialnetwork/opensource-socialnetwork/tree/master)

Thanks to Lucio PANEPINTO for Tetris game (https://github.com/luciopanepinto/tetris)

