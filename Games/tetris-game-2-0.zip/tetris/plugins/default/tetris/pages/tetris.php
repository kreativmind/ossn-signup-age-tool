<div>
<iframe src='components/Tetris/tetris/index.html' width="1000" height="680" frameborder="0" scrolling="no" allowtransparency="true" ></iframe>
</div>
