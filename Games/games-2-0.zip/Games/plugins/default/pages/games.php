<!-- BEGIN - EMBED Channel FROM Come2Play.com -->
<iframe src="http://www.come2play.com/appGame/AllGames.aspx?channel_id=971521" width="1000" height="1230" frameborder="0" scrolling="no" allowtransparency="true" ></iframe>
<div id="c2p" style="text-align:center;width:762;font-family:Tahoma,Arial,sans- serif;font-size:11px;"><a href="http://www.come2play.com/shared/affiliation/setAffiliate.asp?channel_id=971521&next_url=http%3A%2F%2Fwww%2Ecome2play%2Ecom%2Fpublisher%2Easp" target="_blank" >Come<span>2</span>Play</a> - Create your gaming channel</div>
<!-- END - EMBED Channel FROM Come2Play.com -->
