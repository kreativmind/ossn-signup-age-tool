# verified-account

Facebook like "Verified Account" system
 its minor  pre release . please dont use it on production site .

You need to add this component in admin panel and from usermanger -> list .
You need to verify the user . this can be done by admin alone . one more thing 
unverified is not added . soon it will be added . 


Thanks :
Paritosh Pandey - for idea 
Syed Arsalan Hussain Shah - for a nice framework 
Sathish Kumar 
