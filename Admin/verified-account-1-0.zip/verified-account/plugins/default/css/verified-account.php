.tipsy {
    position: absolute;
    top: 0;
    left: 0;
    padding: 6px 8px;
    font-family: sans-serif;
    font-size: 10px;
    line-height: normal;
    color: white;
    -webkit-border-radius: 3px;
    border-radius: 3px;
    background-color: rgba(0,0,0,0.75);
    z-index: 9999;
}

.tipsy:before {
    position: absolute;
    bottom: -5px;
    left: 5px;
    display: inline-block;
    content: '';
    border-right: 5px solid transparent;
    border-top: 5px solid rgba(0,0,0,0.75);
    border-bottom: 0 solid rgba(0,0,0,0.75);
    border-left: 5px solid transparent;
}

.tipsy.arrow-top:before {
    bottom: auto;
    top: -5px;
    border-top-width: 0;
    border-bottom-width: 5px;
}

.tipsy.arrow-bottom:before {
    bottom: -5px;
    top: auto;
    border-top-width: 5px;
    border-bottom-width: 0;
}

.tipsy.arrow-left:before {
    left: 5px;
    right: auto;
}

.tipsy.arrow-center:before {
    left: 50%;
    right: auto;
    margin-left: -5px;
}

.tipsy.arrow-right:before {
    right: 5px;
    left: auto;
}

.tipsy.arrow-side-left:before {
    top: 50%;
    bottom: auto;
    left: 0;
    right: auto;
    margin-top: -5px;
    margin-left: -5px;
    border-right-color: rgba(0,0,0,0.75);
    border-top: 5px solid transparent;
    border-bottom: 5px solid transparent;
    border-left: 0;
}

.tipsy.arrow-side-right:before {
    top: 50%;
font-size:15px;
    bottom: auto;
    right: 0;
    left: auto;
    margin-top: -5px;
    margin-right: -5px;
    border-left-color: rgba(0,0,0,0.75);
    border-top: 5px solid transparent;
    border-bottom: 5px solid transparent;
    border-right: 0;
}