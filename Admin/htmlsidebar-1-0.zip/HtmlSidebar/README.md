# HtmlSiebar
Allow admin to post a html code into right sidebar of page.