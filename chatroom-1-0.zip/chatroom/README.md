# chatroom
a web-based chatroom component for ossn 2.X community
